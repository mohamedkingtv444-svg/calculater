/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  History, 
  Trash2, 
  Settings, 
  Delete, 
  Calculator, 
  ArrowLeftRight, 
  Info,
  Clock
} from "lucide-react";

type Operation = "+" | "-" | "*" | "/" | null;

interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: number;
}

export default function App() {
  const [display, setDisplay] = useState("0");
  const [prevValue, setPrevValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<Operation>(null);
  const [newNumberStarted, setNewNumberStarted] = useState(true);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  
  const displayRef = useRef<HTMLDivElement>(null);

  const calculate = useCallback((first: number, second: number, op: Operation): number => {
    switch (op) {
      case "+": return first + second;
      case "-": return first - second;
      case "*": return first * second;
      case "/": return second !== 0 ? first / second : 0;
      default: return second;
    }
  }, []);

  const handleNumber = useCallback((num: string) => {
    if (newNumberStarted || display === "0") {
      setDisplay(num);
      setNewNumberStarted(false);
    } else {
      if (display.length < 15) {
        setDisplay(display + num);
      }
    }
  }, [display, newNumberStarted]);

  const handleOperation = useCallback((op: Operation) => {
    // If an operator is already active and we haven't started a new number,
    // just switch the operator without calculating.
    if (newNumberStarted && operation !== null) {
      setOperation(op);
      return;
    }

    const current = parseFloat(display);
    
    if (prevValue === null) {
      setPrevValue(current);
    } else if (operation) {
      const result = calculate(prevValue, current, operation);
      setPrevValue(result);
      setDisplay(String(Number(result.toFixed(8))));
    }
    
    setOperation(op);
    setNewNumberStarted(true);
  }, [display, prevValue, operation, calculate, newNumberStarted]);

  const handleEquals = useCallback(() => {
    // Ignore equals if we don't have enough data to calculate
    if (prevValue === null || operation === null || newNumberStarted) return;
    
    const current = parseFloat(display);
    const result = calculate(prevValue, current, operation);
    
    const expression = `${prevValue} ${operation === '*' ? '×' : operation === '/' ? '÷' : operation} ${current}`;
    const resultStr = String(Number(result.toFixed(8)));
    
    setHistory(prev => [{
      id: crypto.randomUUID(),
      expression,
      result: resultStr,
      timestamp: Date.now()
    }, ...prev].slice(0, 50));

    setDisplay(resultStr);
    setPrevValue(null);
    setOperation(null);
    setNewNumberStarted(true);
  }, [display, prevValue, operation, calculate, newNumberStarted]);

  const handleClear = useCallback(() => {
    setDisplay("0");
    setPrevValue(null);
    setOperation(null);
    setNewNumberStarted(true);
  }, []);

  const handlePercentage = useCallback(() => {
    const current = parseFloat(display);
    setDisplay(String(current / 100));
  }, [display]);

  const handleToggleSign = useCallback(() => {
    const current = parseFloat(display);
    setDisplay(String(current * -1));
  }, [display]);

  const handleDecimal = useCallback(() => {
    if (newNumberStarted) {
      setDisplay("0.");
      setNewNumberStarted(false);
    } else if (!display.includes(".")) {
      setDisplay(display + ".");
    }
  }, [display, newNumberStarted]);

  const handleDelete = useCallback(() => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay("0");
    }
  }, [display]);

  // Keyboard Support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= "0" && e.key <= "9") handleNumber(e.key);
      if (e.key === ".") handleDecimal();
      if (e.key === "+") handleOperation("+");
      if (e.key === "-") handleOperation("-");
      if (e.key === "*") handleOperation("*");
      if (e.key === "/") handleOperation("/");
      if (e.key === "Enter" || e.key === "=") handleEquals();
      if (e.key === "Escape") handleClear();
      if (e.key === "Backspace") handleDelete();
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleNumber, handleDecimal, handleOperation, handleEquals, handleClear, handleDelete]);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-soft-bg">
      {/* Calculator Body */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: "spring", damping: 20, stiffness: 100 }}
        className="relative bg-[#1A1A1A] p-8 rounded-[40px] shadow-[0_40px_100px_rgba(0,0,0,0.3)] w-full max-w-[400px] border border-white/5"
      >
        {/* Header Decor */}
        <div className="flex justify-between items-start mb-8">
          <div className="flex gap-2">
            <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
            <div className="text-[10px] uppercase tracking-[0.2em] text-white/30 font-mono">
              Swinga OS v2.0
            </div>
          </div>
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className="p-2 -mt-1 rounded-full hover:bg-white/10 transition-colors text-white/50"
          >
            <Clock size={18} />
          </button>
        </div>

        {/* Display Container */}
        <div className="relative mb-8 bg-[#2A2A2A] p-6 rounded-2xl border border-white/5 overflow-hidden group min-h-[110px] flex flex-col justify-center">
          <div className="absolute top-2 right-2 flex gap-1 opacity-50 group-hover:opacity-100 transition-opacity">
            <div className="w-1 h-3 bg-accent/50 rounded-full" />
            <div className="w-1 h-2 bg-accent/30 rounded-full" />
          </div>
          
          <div 
            ref={displayRef}
            className="text-right text-4xl font-mono text-white tracking-tighter overflow-hidden flex items-baseline justify-end flex-nowrap whitespace-nowrap"
          >
            <AnimatePresence mode="popLayout" initial={false}>
              {(() => {
                const opIcon = operation === '*' ? '×' : operation === '/' ? '÷' : operation;
                
                // If operator is set and we're waiting for a new number, don't show the second operand yet
                let fullExpr = display;
                if (prevValue !== null && operation) {
                  fullExpr = newNumberStarted 
                    ? `${prevValue} ${opIcon}` 
                    : `${prevValue} ${opIcon} ${display}`;
                }
                
                return fullExpr.split('').map((char, index) => (
                  <motion.span
                    key={`${index}-${char}`}
                    initial={{ opacity: 0, y: 15, filter: "blur(4px)" }}
                    animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                    exit={{ opacity: 0, scale: 0.8, filter: "blur(4px)" }}
                    transition={{ type: "spring", damping: 15, stiffness: 300 }}
                    className={`inline-block flex-shrink-0 ${char === ' ' ? 'w-2' : ''} ${['+', '-', '×', '÷'].includes(char) ? 'text-accent px-1' : ''}`}
                    style={{ display: 'inline-block' }}
                  >
                    {char}
                  </motion.span>
                ));
              })()}
            </AnimatePresence>
          </div>
        </div>

        {/* Keypad */}
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.03
              }
            }
          }}
          className="grid grid-cols-4 gap-3"
        >
          {/* Row 1 */}
          <CalcButton label="AC" onClick={handleClear} variant="utility" />
          <CalcButton label="+/-" onClick={handleToggleSign} variant="utility" />
          <CalcButton label="%" onClick={handlePercentage} variant="utility" />
          <CalcButton label="÷" onClick={() => handleOperation("/")} variant="action" active={operation === "/"} />

          {/* Row 2 */}
          <CalcButton label="7" onClick={() => handleNumber("7")} />
          <CalcButton label="8" onClick={() => handleNumber("8")} />
          <CalcButton label="9" onClick={() => handleNumber("9")} />
          <CalcButton label="×" onClick={() => handleOperation("*")} variant="action" active={operation === "*"} />

          {/* Row 3 */}
          <CalcButton label="4" onClick={() => handleNumber("4")} />
          <CalcButton label="5" onClick={() => handleNumber("5")} />
          <CalcButton label="6" onClick={() => handleNumber("6")} />
          <CalcButton label="-" onClick={() => handleOperation("-")} variant="action" active={operation === "-"} />

          {/* Row 4 */}
          <CalcButton label="1" onClick={() => handleNumber("1")} />
          <CalcButton label="2" onClick={() => handleNumber("2")} />
          <CalcButton label="3" onClick={() => handleNumber("3")} />
          <CalcButton label="+" onClick={() => handleOperation("+")} variant="action" active={operation === "+"} />

          {/* Row 5 */}
          <CalcButton label="0" onClick={() => handleNumber("0")} wide />
          <CalcButton label="." onClick={handleDecimal} />
          <CalcButton label="=" onClick={handleEquals} variant="accent" />
        </motion.div>

        {/* History Overlay */}
        <AnimatePresence>
          {showHistory && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="absolute inset-0 bg-[#1A1A1A] z-10 rounded-[40px] p-8 flex flex-col"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-white/60 text-xs font-mono uppercase tracking-widest">History</h3>
                <button 
                  onClick={() => setShowHistory(false)}
                  className="p-2 rounded-full hover:bg-white/10 transition-colors text-white/50"
                >
                  <ArrowLeftRight size={18} className="rotate-90" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-hide">
                {history.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-white/20 space-y-4">
                    <History size={40} strokeWidth={1} />
                    <p className="text-[10px] tracking-widest uppercase">No history data</p>
                  </div>
                ) : (
                  history.map((item) => (
                    <motion.div 
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="group cursor-pointer"
                      onClick={() => {
                        setDisplay(item.result);
                        setNewNumberStarted(true);
                        setShowHistory(false);
                      }}
                    >
                      <div className="text-[10px] text-white/30 font-mono mb-1">{item.expression}</div>
                      <div className="text-xl text-white font-mono flex items-center justify-between">
                        <span>= {item.result}</span>
                        <ArrowLeftRight size={14} className="opacity-0 group-hover:opacity-40 transition-opacity" />
                      </div>
                    </motion.div>
                  ))
                )}
              </div>

              <button 
                onClick={() => setHistory([])}
                className="mt-4 py-3 flex items-center justify-center gap-2 text-[10px] uppercase tracking-widest text-white/40 hover:text-red-400 transition-colors"
              >
                <Trash2 size={14} />
                Clear Logs
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer info */}
        <div className="mt-8 pt-6 border-t border-white/5 flex justify-between items-center px-2">
          <div className="text-[8px] text-white/20 font-mono leading-none">
            ENGINE TYPE: FLOATING POINT<br />
            PRECISION: 8 DECIMAL PLACES
          </div>
          <Calculator size={14} className="text-white/10" />
        </div>
      </motion.div>
    </div>
  );
}

interface CalcButtonProps {
  label: string;
  onClick: () => void;
  variant?: "number" | "action" | "utility" | "accent";
  wide?: boolean;
  active?: boolean;
}

function CalcButton({ label, onClick, variant = "number", wide = false, active = false }: CalcButtonProps) {
  const btnVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { opacity: 1, scale: 1 }
  };

  const colorVariants = {
    number: "bg-[#2D2D2D] text-white hover:bg-[#3D3D3D]",
    action: active ? "bg-accent text-white" : "bg-white/10 text-white/80 hover:bg-white/20",
    utility: "bg-white/5 text-white/50 hover:bg-white/10",
    accent: "bg-accent text-white hover:bg-accent/90"
  };

  return (
    <motion.button
      variants={btnVariants}
      whileHover={{ scale: 1.05, y: -2 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        ${colorVariants[variant]}
        ${wide ? "col-span-2" : "col-span-1"}
        h-14 rounded-2xl flex items-center justify-center
        text-lg font-mono transition-colors duration-150 relative overflow-hidden
      `}
    >
      {label}
      {active && (
        <motion.div 
          layoutId="active-indicator"
          className="absolute inset-0 bg-white/20"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        />
      )}
    </motion.button>
  );
}
